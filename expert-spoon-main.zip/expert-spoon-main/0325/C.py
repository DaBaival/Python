n = int( input("整数n:"))
Max = int( input("第1整:"))
i = 2
while(i <= n):
   print("第",i,"整:", end='')
   num = int( input())
   if num > Max: