age = int(input("Enter your age: "))
height=int(input("Enter your height: "))
if age>=18 and age<=30 and height>=170 and height<=185:
    print("You are")
else:
    print("You NO are")