a="Hello"
b="python"
print("a+b:",a+b)
print("a*2:",a*2)
print("a[1]:",a[1])
print("a[1:4]:",a[1:4])
if("H" in a):
    print("H" in a)
else:
    print("H" not in a)
if("M" not in a):
    print("M" not in a)
else:
    print("M" in a)
print(r'\n')
print(R'\n')