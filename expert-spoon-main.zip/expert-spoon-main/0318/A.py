import sys
print(sys.maxsize)
print(sys.maxsize-1)