s=input("Enter:")
t=""
for c in s:
    if c=='0':
        t+='零'
    elif c=='1':
        t+='一'
    elif c=='2':
        t+='二'
    elif c=='3':
        t+='三'
    elif c=='4':
        t+='四'
    elif c=='5':
        t+='五'
    elif c=='6':
        t+='六'
    elif c=='7':
        t+='七'
    elif c=='8':
        t+='八'
    elif c=='9':
        t+='九'
print("Enter:",t)
