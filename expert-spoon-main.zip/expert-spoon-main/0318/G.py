import math
print(math.ceil(4.12))
print(math.cos(math.pi/4))
print(math.degrees(math.pi/4))
print(math.exp(2))
print(math.floor(4.999))
print(math.fmod(20,3))
print(math.gcd(8,6))
print(math.tan(math.pi/4))