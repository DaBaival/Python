b="WWW.itdiffer.com"
c=b.split(".")
print(c)
d=".".join(c)
print(d)
e="*".join(c)
print(e)