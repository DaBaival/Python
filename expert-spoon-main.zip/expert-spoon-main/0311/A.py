a=int(input("py 1=A 2=B 3=C"))

if a==1:
    print("A1")
elif a==2:
    print("B2")
else:
    print("C3")